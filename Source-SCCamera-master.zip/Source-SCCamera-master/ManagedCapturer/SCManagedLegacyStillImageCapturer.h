//
//  SCManagedLegacyStillImageCapturer.h
//  Snapchat
//
//  Created by Chao Pang on 10/4/16.
//  Copyright © 2016 Snapchat, Inc. All rights reserved.
//

#import "SCManagedStillImageCapturer.h"

@interface SCManagedLegacyStillImageCapturer : SCManagedStillImageCapturer

@end
